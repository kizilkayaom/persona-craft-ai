import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Ignore benign Vite HMR websocket connection errors in AI Studio preview iframe
if (typeof window !== "undefined") {
  const isBenignError = (msg: string) => {
    const m = msg.toLowerCase();
    return (
      m.includes("websocket") ||
      m.includes("vite") ||
      m.includes("ws://") ||
      m.includes("wss://") ||
      m.includes("hmr") ||
      m.includes("closed without opened") ||
      m.includes("connection failed")
    );
  };

  window.addEventListener("unhandledrejection", (event) => {
    const reason = event.reason;
    const msg = reason?.message || String(reason || "");
    if (isBenignError(msg)) {
      event.stopImmediatePropagation();
      event.preventDefault();
    }
  });

  window.addEventListener("error", (event) => {
    const msg = event.message || "";
    if (isBenignError(msg)) {
      event.stopImmediatePropagation();
      event.preventDefault();
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
